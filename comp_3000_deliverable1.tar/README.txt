COMP3004 cuACS Deliverable #1
Due February 12, 2019

A-Team:

Farhoud Talebi - Team Leader - 100965969
Lewis Yu                     - 100952460
Bence Meszaros               - 100833054
Simon Roy-Halverson          - 100985755

Purpose:

    This application serves to provide a platform where clients are able to be matched with an animal from an adoption centre.

Compilation command:

    Run the shell script "build_linux.sh", i.e. `./build_linux.sh`.

Launching command:

    Run the shell script "run_linux.sh", i.e. `./run_linux.sh`.

Program Instruction:

    For deliverable #1, we have implemented functionality for:
        Viewing Animals
        Adding Animals

    Once application is launched, the user will be able to log in as client or staff.

    Once logged in as client, the user is able to view the list of 5 animals we loaded in.

    Once logged in as staff, the user is able to both view the list of animals and add new Animals.

    Application can be closed by clicking the "X" button.
