#!/bin/bash

cd ./build

./cuACS
