#include "staff.h"

bool Staff::isStaff()
{
    return true;
}
