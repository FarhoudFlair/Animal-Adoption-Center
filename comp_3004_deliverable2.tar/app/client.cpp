#include "client.h"

bool Client::isStaff()
{
    return false;
}
