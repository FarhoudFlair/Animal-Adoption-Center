#include "viewanimalcontrol.h"

ViewAnimalControl::ViewAnimalControl()
{

}
