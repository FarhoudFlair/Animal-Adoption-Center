#ifndef EDITCLIENTPROFILECONTROL_H
#define EDITCLIENTPROFILECONTROL_H


class EditClientProfileControl
{
public:
    EditClientProfileControl();
};

#endif // EDITCLIENTPROFILECONTROL_H