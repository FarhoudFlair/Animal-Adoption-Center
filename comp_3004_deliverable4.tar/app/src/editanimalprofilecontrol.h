#ifndef EDITANIMALPROFILECONTROL_H
#define EDITANIMALPROFILECONTROL_H


class EditAnimalProfileControl
{
public:
    EditAnimalProfileControl();
};

#endif // EDITANIMALPROFILECONTROL_H