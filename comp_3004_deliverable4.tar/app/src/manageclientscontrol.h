#ifndef MANAGECLIENTSCONTROL_H
#define MANAGECLIENTSCONTROL_H


class ManageClientsControl
{
public:
    ManageClientsControl();
};

#endif // MANAGECLIENTSCONTROL_H