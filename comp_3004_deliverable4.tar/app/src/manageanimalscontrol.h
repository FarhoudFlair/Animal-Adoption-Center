#ifndef MANAGEANIMALSCONTROL_H
#define MANAGEANIMALSCONTROL_H


class ManageAnimalsControl
{
public:
    ManageAnimalsControl();
};

#endif // MANAGEANIMALSCONTROL_H