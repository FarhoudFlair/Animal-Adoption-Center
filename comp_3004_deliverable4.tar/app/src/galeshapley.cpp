#include "include/galeshapley.h"

// this file is empty becayse GaleShapley is a template class
