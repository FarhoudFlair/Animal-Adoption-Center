#ifndef VIEWCLIENTPROFILECONTROL_H
#define VIEWCLIENTPROFILECONTROL_H


class ViewClientProfileControl
{
public:
    ViewClientProfileControl();
};

#endif // VIEWCLIENTPROFILECONTROL_H