#ifndef VIEWCLIENTLISTCONTROL_H
#define VIEWCLIENTLISTCONTROL_H


class ViewClientListControl
{
public:
    ViewClientListControl();
};

#endif // VIEWCLIENTLISTCONTROL_H