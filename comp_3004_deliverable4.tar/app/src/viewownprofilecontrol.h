#ifndef VIEWOWNPROFILECONTROL_H
#define VIEWOWNPROFILECONTROL_H


class ViewOwnProfileControl
{
public:
    ViewOwnProfileControl();
};

#endif // VIEWOWNPROFILECONTROL_H