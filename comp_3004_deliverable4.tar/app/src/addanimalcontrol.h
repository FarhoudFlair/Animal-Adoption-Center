#ifndef ADDANIMALCONTROL_H
#define ADDANIMALCONTROL_H


class AddAnimalControl
{
public:
    AddAnimalControl();
};

#endif // ADDANIMALCONTROL_H