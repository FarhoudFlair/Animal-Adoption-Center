#include "viewalgorithmsummarycontrol.h"

ViewAlgorithmSummaryControl::ViewAlgorithmSummaryControl()
{

}
