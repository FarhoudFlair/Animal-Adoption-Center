#ifndef ACCESSANIMALSCONTROL_H
#define ACCESSANIMALSCONTROL_H


class AccessAnimalsControl
{
public:
    AccessAnimalsControl();
};

#endif // ACCESSANIMALSCONTROL_H