#ifndef VIEWALGORITHMSUMMARYCONTROL_H
#define VIEWALGORITHMSUMMARYCONTROL_H


class ViewAlgorithmSummaryControl
{
public:
    ViewAlgorithmSummaryControl();
};

#endif // VIEWALGORITHMSUMMARYCONTROL_H