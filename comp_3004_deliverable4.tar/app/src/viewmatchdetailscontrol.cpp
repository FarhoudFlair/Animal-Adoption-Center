#include "viewmatchdetailscontrol.h"

ViewMatchDetailsControl::ViewMatchDetailsControl()
{

}
