#ifndef LAUNCHALGORITHMCONTROL_H
#define LAUNCHALGORITHMCONTROL_H


class LaunchAlgorithmControl
{
public:
    LaunchAlgorithmControl();
};

#endif // LAUNCHALGORITHMCONTROL_H