#ifndef ADDCLIENTCONTROL_H
#define ADDCLIENTCONTROL_H


class AddClientControl
{
public:
    AddClientControl();
};

#endif // ADDCLIENTCONTROL_H