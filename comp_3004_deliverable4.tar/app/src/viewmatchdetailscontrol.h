#ifndef VIEWMATCHDETAILSCONTROL_H
#define VIEWMATCHDETAILSCONTROL_H


class ViewMatchDetailsControl
{
public:
    ViewMatchDetailsControl();
};

#endif // VIEWMATCHDETAILSCONTROL_H