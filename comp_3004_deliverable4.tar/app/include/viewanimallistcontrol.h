#ifndef VIEWANIMALLISTCONTROL_H
#define VIEWANIMALLISTCONTROL_H

#include "include/sqlserializer.h"
#include "ui_mainwindow.h"

class ViewAnimalListControl
{
public:
    ViewAnimalListControl();
    void launch(Ui::MainWindow *);
};

#endif // VIEWANIMALLISTCONTROL_H
