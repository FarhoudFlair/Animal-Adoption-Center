#ifndef VIEWANIMALCONTROL_H
#define VIEWANIMALCONTROL_H


class ViewAnimalControl
{
public:
    ViewAnimalControl();
};

#endif // VIEWANIMALCONTROL_H